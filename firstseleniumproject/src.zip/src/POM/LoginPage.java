package POM;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
	//object repository
	
	@FindBy(id="username")
	private WebElement TxtBox;  
	
	@FindBy(id="pwd")
	private WebElement pswd;
	
	@FindBy(id="loginButton")
	private WebElement loginBtn;
	
	
	
	

}
