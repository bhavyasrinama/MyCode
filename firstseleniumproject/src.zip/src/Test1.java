import org.junit.Test;

public class Test1 {


		
		
		@Test
		public void login(){
			System.out.println("hiii");
		}
		
	

	}


